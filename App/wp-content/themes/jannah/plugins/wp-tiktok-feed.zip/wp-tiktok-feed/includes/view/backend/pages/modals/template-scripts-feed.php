<script type="text/html" id='tmpl-qlttf-modal-main'>
<?php include_once(QLTTF_PLUGIN_DIR . 'includes/view/backend/pages/modals/feed/main.php'); ?> 
</script>

<script type="text/html" id='tmpl-qlttf-modal-tabs'>
<?php include_once('feed/panel-tabs.php'); ?> 
</script>

<script type="text/html" id='tmpl-qlttf-modal-panels'>
  <?php include_once('feed/panel-feed.php'); ?> 
  <?php include_once('feed/panel-feed-video.php'); ?> 
  <?php include_once('feed/panel-feed-video-popup.php'); ?> 
  <?php include_once('feed/panel-feed-button.php'); ?>
</script>

